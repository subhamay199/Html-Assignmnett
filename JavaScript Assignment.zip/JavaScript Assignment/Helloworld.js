function sayHello(){  
 document.write('Say Hello');  
}  